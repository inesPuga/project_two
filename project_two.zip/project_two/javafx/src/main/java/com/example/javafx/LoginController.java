package com.example.javafx;

import com.example.database.DAL.Utilizador;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import com.example.database.BLL.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    Logic logic = new Logic();
    @FXML
    private TextField textField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label msgLabel;

    @FXML
    public void onLoginButtonClick(javafx.event.ActionEvent event) throws IOException {
        String password = LogicDataBase.passEncrypt(passwordField.getText());
        int res = logic.verifyLogin(textField.getText(), password);
        Utilizador user = logic.searchuserbylogin(textField.getText(), password);
        if(res==1) {
            msgLabel.setText("Dados incorretos");
        }
        if(res==0) {
            msgLabel.setText("Dados corretos");
            //menuAdmin
            if(user.getCargo().equals("A")) {
                Scene scene = logic.changePanel(event, "menuAdmin-view.fxml", "Conserveira", 500, 500);
                scene.setUserData(user);
            }
            if(user.getCargo().equals("G")) {
                logic.changePanel(event, "menuManager-view.fxml", "Conserveira", 500, 500);
            }
        }
    }

    public void onHyperLinkClick(javafx.event.ActionEvent event) throws IOException {
        logic.changePanel(event, "change_password-view.fxml", "Conserveira", 500, 500);
    }

}
