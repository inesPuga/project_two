package com.example.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import com.example.database.DAL.*;
import com.example.database.BLL.*;

import java.io.IOException;

public class ChangePasswordController {
    Logic logic = new Logic();
    @FXML
    private TextField textField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField passwordField1;
    @FXML
    private Button confirmButton;
    @FXML
    private Label label;

    public void onConfirmButtonClick(javafx.event.ActionEvent event) throws IOException {
        Utilizador user = search_user(textField.getText());
        if(user == null) {
            label.setText("E-mail incorreto");
        }
        else {
            if(check_passwords(passwordField.getText(), passwordField1.getText())==1) {
                label.setText("As palavras-passe são diferentes");
            }
            else {
                String password = LogicDataBase.passEncrypt(passwordField.getText());
                user.setPassword(password);
                UtilizadorBLL.update(user);
                logic.changePanel(event, "login-view.fxml", "Conserveira", 500, 500);
            }
        }
    }

    public int check_passwords(String str1, String str2) {
        if(str1.equals(str2)) {
            return 0;
        }
        return 1; //error
    }

    public Utilizador search_user(String str) {
        for(Utilizador u : UtilizadorBLL.readAll()) {
            if(u.getEmail().equals(str)) {
                return u;
            }
        }
        return null;
    }

}
