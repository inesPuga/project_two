package com.example.javafx;

import com.example.database.DAL.*;
import com.example.database.BLL.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class Logic {

    public int verifyLogin(String text1, String text2) {
        //verify login
        List <Utilizador> users = UtilizadorBLL.readAll();
        System.out.println(users);
        for(Utilizador i : users) {
            if(i.getUsername().equals(text1) || i.getEmail().equals(text1)) {
                if(i.getPassword().equals(text2)) {
                    return 0; //user exist -> login -> success
                }
            }
        }
        return 1;   //error
    }

    public Utilizador searchuserbylogin(String text1, String text2) {
        List <Utilizador> users = UtilizadorBLL.readAll();
        System.out.println(users);
        for(Utilizador i : users) {
            if(i.getUsername().equals(text1) || i.getEmail().equals(text1)) {
                if(i.getPassword().equals(text2)) {
                    return i;
                }
            }
        }
        return null;
    }

    public Scene changePanel(javafx.event.ActionEvent event, String name_fxml, String name_view, int v, int v1) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(name_fxml)));
        Scene scene = new Scene(parent, v, v1);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setTitle(name_view);
        stage.show();

        return scene;
    }

}
