package com.example.database;

import com.example.database.BLL.CPostalBLL;
import com.example.database.BLL.LogicDataBase;
import com.example.database.BLL.UtilizadorBLL;
import com.example.database.DAL.*;


public class main {
    public static void main(String[] args) {
        /*Utilizador user = new Utilizador();
        user.setNome("Inês Puga Alves");
        user.setUsername("inespuga");
        String psw = LogicDataBase.passEncrypt("piloto");
        user.setPassword(psw);
        user.setCargo("A");
        user.setEmail("inespuga2002@gmail.com");
        user.setNumtel(969890424);
        UtilizadorBLL.create(user);*/
    }
}
